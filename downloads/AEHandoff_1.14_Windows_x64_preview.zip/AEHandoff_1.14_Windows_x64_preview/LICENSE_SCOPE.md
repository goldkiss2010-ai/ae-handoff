# このパッケージのライセンス

Copyright (c) 2026 Bungaku Yokota.
AEHandoff.aexの自作部分と付属の自作文書はMITです。LICENSEとEULA.mdを参照してください。
Adobe SDK由来部分はMIT対象外です。THIRD_PARTY_NOTICES.mdを参照してください。
提供されたSDK表示一覧（99ファイル・44表示）の照合・原文同梱は完了しています。確認範囲はTHIRD_PARTY_NOTICES.mdを参照してください。
プラグインのソース・ビルド設定・開発履歴は非公開で、同梱していません。

samples/のFLD1と付属JSONについて、Bungaku Yokotaは保有する著作権および関連する権利を
CC0 1.0 Universalに従って放棄します。LICENSES/CC0-1.0.txtを参照してください。
素材の商用利用・改変・再配布にクレジットは不要です。MITはソース公開を義務にしません。
ソフトウェア自体を再配布する場合は、適用されるライセンスと第三者表示を保持してください。
映像への作者クレジットは不要です。今回の選択でAdobeや第三者の権利を変更するものではありません。
