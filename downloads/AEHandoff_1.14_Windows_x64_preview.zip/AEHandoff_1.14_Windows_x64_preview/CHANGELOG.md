# AE Handoff 1.14 development build 1

- AE Handoffを最上段に置き、Mode、Select File、Sprite / Mask関連設定を集約。
- RenderingをPlaybackの前へ移動。
- 粒子数の操作をDensityへ集約。
- 時間操作をSamples / SecondとSample Offsetへ整理。
- 旧時間設定の保存IDと旧FLD1の補間間隔換算を維持。
- WindowsビルドとAEでの基本動作を作者が確認し、試験用バイナリを受領。
- 2026-10-04、新しい添付.aexへ差し替え。登録情報・Release用依存DLL・ハッシュを確認。
  同日、差し替えZIPもAE基本動作成功との作者報告を受領。実装・UIの変更は行っていません。

UI・保存参照の実装と、実機で確認した範囲はREADMEの検証記録を参照してください。
