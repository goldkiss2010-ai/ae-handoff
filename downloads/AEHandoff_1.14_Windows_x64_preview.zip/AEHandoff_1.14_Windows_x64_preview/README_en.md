# AE Handoff 1.14 — Windows x64 preview

A compiled After Effects particle-state player, with a small FLD1 example.
Python, Visual Studio and the AE SDK are not needed to play existing caches.
This is a Windows x64 preview package. Original plugin contributions are MIT; bundled sample data and settings are CC0-1.0. Adobe components are excluded from the MIT grant.

## Install

1. Quit After Effects and extract the ZIP.
2. Copy AEHandoff.aex into your installed AE version's Plug-ins folder:

   ```text
   C:\Program Files\Adobe\Adobe After Effects <your version>\Support Files\Plug-ins\AEHandoff\AEHandoff.aex
   ```

   Use the equivalent folder if AE is installed elsewhere. Replace an older copy;
   avoid duplicate copies of this effect. Keep FLD1 files with your project data.
3. Restart AE and search for the AE Handoff effect.

The binary uses the Visual C++ v14 x64 Runtime (same or newer than the build toolset).
If runtime DLLs are missing or loading fails, use the official Microsoft installer:
https://aka.ms/vc14/vc_redist.x64.exe
Information: https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist/

## Try the sample

Create a comp-sized solid in a 1920x1080 composition and apply AE Handoff.
Choose samples/orbit-sample-index.fld1 via AE Handoff → Select File → Choose...
Use Mode=Dot, Density=100%, Size Multiplier=1, Speed Brightness=0,
Velocity Streak=0, Samples / Second=12 and Sample Offset=0.
Scrub 0–2 seconds to observe analytic circular motion; later times hold the endpoint.
The sample has 128 particles and 25 stored samples, with sample_rate=1.
The companion JSON is descriptive and is not automatically applied by AE.

Progress is stored-sample index = AE time × Samples / Second + Sample Offset.
For direct retiming, set Samples / Second=0 and animate Sample Offset.
Use Refresh File → Reload after externally modifying a cache at the same path.
FLD1 data is not embedded in .aep; keep it with the project and reselect it on another PC.
Relative path resolution, automatic search and Collect Files integration are not implemented.

## Verification and scope

The author previously reported a successful independent-project Windows build and basic operation in AE.
A replacement binary was received on 2026-10-04. The author subsequently reported successful basic AE operation with the replacement ZIP on the same date.
Exact AE and Windows versions have not yet been recorded; a compatibility range
is not claimed. Save/restart reference restoration, duplication, undo/redo,
other PCs and individual particle-field assets remain to be tested.

Packaging checks verified x64 PE/DLL format, expected exports, PiPL version,
release runtime imports, a Release PDB reference, equality to the new uploaded binary bytes,
and the sample cache layout/finite values.
See BUILD_INFO.json and SHA256SUMS.txt for identifiers and hashes.
The author supplied the prebuilt binary; byte-for-byte reproducible
compilation has not been independently verified.

Large particle fields are separate assets. No .aep, SDK or runtime installer is included.
Source projects:
https://github.com/goldkiss2010-ai/ae-handoff
https://github.com/goldkiss2010-ai/fld1

Adobe installation-folder reference:
https://helpx.adobe.com/jp/after-effects/kb/cq02250243.html

## Distribution scope

The AE plugin is planned as a compiled Windows x64 distribution. Plugin C++
source, build configuration and development history remain private. FLD1
specifications, reference tools and particle-field generators are separate
public-scope deliverables. Custom FLD1 generation does not require plugin source.
License selection for original material is complete. The supplied SDK notice inventory has been reviewed; all 44 notice blocks are retained verbatim. The reviewed scope is described in THIRD_PARTY_NOTICES.md.

## Licenses

See LICENSE, LICENSE_SCOPE.md, LICENSES/CC0-1.0.txt, EULA.md and
THIRD_PARTY_NOTICES.md. MIT covers only original plugin contributions; CC0
covers the included sample data/settings. Adobe components are excluded.
Plugin source stays private; no on-screen author credit is required.
